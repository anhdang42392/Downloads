 #include <iostream> 
 #include <cmath>
 #include <stdio.h>
 #include <iomanip>
 #include <string>


   using namespace std; 
  
   int main() 
   { 
    //    int a = 0;
    //    int b = a + 2;
    //    char c = 'K' ;
    //    cout << "C = " << c <<endl ;
    //    cout << "a: " << a <<endl;
    //    cout <<"b: " << b <<endl ;
    //    a = b *4 ;
    //    cout << "b*4 = " << a << endl;
    //    b = static_cast<int>(round((static_cast<double>(a)) / 3.14)) ;
    //    cout << "a / 3.14 = " <<(static_cast<double>(a)) / 3.14  << endl;
    //    cout << "a / 3.14 = " << b << endl;
    //    a = b - 8 ;
    //    cout << "b - 8 = " << a << endl;
    //     a = 27 ;
    //     c = 66 ;
    //     cout << "c is " << c << endl ;
    //     cout << "Two mandolins like creatures in the" << endl << endl; 
    //  cout << "dark"<< endl <<  endl; 
    //  cout << "Creating the agony of ecstasy." << endl << endl; 
    //  cout << "                  - George Barker" << endl; 
    // double percent = 0.58;
    // int sales = 8600000;
    // cout << "The division: " << static_cast<int>(round(static_cast<double>(sales) * percent)) <<endl;


    //     double meal = 88.67;
    //     double tax = meal * 0.0675 + meal;
    //     double tip = tax * 0.2 ;
    //     double total = tip + tax;
    //     cout << "The meal cost: " << static_cast<int>(round(meal)) << endl;
    //     cout << "The tax: " << static_cast<int>(round(meal * 0.0675)) << endl ;
    //     cout << "The tip: " << static_cast<int>(round(tip)) <<endl;
    //     cout << "The total: " << static_cast<int>(round(total)) <<endl ;


    //     int number[5] = {28,32,37,24,33} ;
    //     int sum = 0;
    //     for(int i = 0;i < 5; i++){
    //         sum += number[i] ;
    //     }
    //     int aver = sum / 5;
    //     cout << "The average: " << aver << endl;



    //     double payAmount = 2200.0;
    //     double payPeriods = 26 ;
    //     double annualPay = payAmount * payPeriods ;
    //     cout << "The total annual pay: " << annualPay << endl; 


    //     double sealevel = 1.5 ;
    //     double level5 = 1.5*5 - 1.5 ;
    //     double level7 = 1.5*6 ;
    //     double level10=  1.5*9;
    //     cout << "The level in 5 years: " << level5 <<endl ;
    //     cout << "The level in 7 years: " << level7 <<endl ;
    //     cout << "The level in 10 years: " << level10 <<endl ;

    //     double item1 = 15.95;
    //     double item2 = 24.95 ;
    //     double item3 = 6.95;
    //     double item4 = 12.95;
    //     double item5 = 3.95;
    //     double subtotal = item1 + item2 + item3 + item4 + item5;
    //     double taxsale =  subtotal * 0.07;
    //     double totalsale = subtotal + taxsale ;
    //     cout << "The price of item 1: " << item1 << endl;
    //     cout << "The price of item 2: " << item2 << endl;
    //     cout << "The price of item 3: " << item3 << endl;
    //     cout << "The price of item 4: " << item4 << endl;
    //     cout << "The price of item 5: " << item5 << endl;
    //     cout << "The subtotal of the sale: " << subtotal << endl;
    //     cout << "The amount of sales tax: " << taxsale << endl;
    //     cout << "The total: " << totalsale << endl;



    //     cout << "The size of char: " << sizeof(char) << " bytes" << endl;
    //     cout << "The size of int: " << sizeof(int) << " bytes" << endl;
    //     cout << "The size of float: " << sizeof(float) << " bytes" << endl;
    //     cout << "The size of double: " << sizeof(double) << " bytes"<< endl;

    //     double miles = 375;
    //     double gallon = 15 ;
    //     cout << "The MPG: " << miles / gallon << endl;
        

    //     double acres = 391.876 / 43.560 ;
    //     cout <<  "The number of acres: " << acres << endl;
        
    //     double board = 14.95 * 0.35 + 14.95 ;
    //     cout << "The selling price of board: " << board << endl;

    //     cout << "My name: DANG TUAN ANH " << endl << "Address: Viet Nam" << endl << "Da Nang city" << endl << "Lien Chieu district" <<endl<<"Telephone: 0363838247"<< endl << "Major: embedded system"<< endl;
    //     cout << "   *   "<< endl << "  ***  " << endl << " ***** " << endl << "*******" << endl;
    //     cout << " ***** "<< endl << "  ***  " << endl << "   *   " << endl;

    //     double stock = 35.00 + 35.00 * 0.02 ;
    //     cout << "The total amount paid: " << 750 * stock << endl ;

    //     cout << "The approximate of number of customers in the survey who purchase one or more energy drink per week: " << 16500 * 0.15 << endl;
    //     cout << "The approximate of number of customers in the survey who prefer citrus-flavored per week: " << 16500 * 0.58 << endl;
    //     int length , width;
    //     cout << "Enter the length: " ; cin >> length ;
    //     cout << "Enter the  width: " ; cin >> width ;
    //     long int area = length * width ;
    //     cout << "the size of area: " << sizeof(area) << endl ;
    //     cout  << "The area: " << area << endl ;
    //     cout << "size short: " << sizeof(short) << endl;


    //     float test ;
    //     test = 2.0e38 *1000 ;
    //     cout<< test << endl;
    //     test = 2.0e-38 / 2.0e38;
    //     cout << test << endl;

      //     int value = 12345;
      //     cout << setw(7) << value << endl ;


    //     double num1 = 132.364;
    //     double num2 = 26.91;
    //     double quotient = num1 /num2 ;
    //     cout << quotient << endl ;
    //     cout << setprecision(5) << quotient << endl;
    //     cout << setprecision(4) << quotient << endl;
    //     cout << setprecision(3) << quotient << endl;
    //     cout << setprecision(2) << quotient << endl;
    //     cout << setprecision(1) << quotient << endl; 

    //     cout << setprecision(2) << fixed ;
    //     cout << quotient << endl ;

    //     double day1, day2, day3, totalday; 
  
    //    // Get the sales for each day. 
    //    cout << "Enter the sales for day 1: "; 
    //    cin >> day1; 
    //    cout << "Enter the sales for day 2: "; 
    //    cin >> day2; 
    //    cout << "Enter the sales for day 3: "; 
    //    cin >> day3; 
  
    //    // Calculate the total sales. 
    //    totalday = day1 + day2 + day3; 
  
    //    // Display the sales figures. 
    //    cout << "\nSales Figures\n"; 
    //   cout << "-------------\n"; 
    //    cout << setprecision(4) << fixed; 
    //    cout << "Day 1: "  << day1 << endl; 
    //    cout << "Day 2: "  << day2 << endl; 
    //    cout << "Day 3: "  << day3 << endl; 
    //    cout << "Total: "  << totalday << endl; 

    //     double num3 = 34.789;
    //     cout << left<< setw(9) << num3 << endl ;
    //     cout << setprecision(2) << fixed <<  setw(9) << num3 << endl ;
    //     cout << right ;
    //     cout << right << setw(5) << setprecision(3) << fixed << showpoint << 7.0 << endl;
         cout << setprecision(1) << fixed << showpoint<<  5.789e+12 << endl;

        //cout << left << setw(7) << 67 << endl ;
        char charac ;
        cout << "Enter char: " ;
        cin >> charac ;
        cin.ignore() ;
        char ch ;
        cout << "Enter the char: " ;
        cin.get(ch) ;
        cout << "\nThe char is: " << ch << endl;
        
    //     string name1 = "Viet Nam" ;
    //     cout << "size of name1: " << name1.length();
            double gas , miles;
            cout << "Full tank: " ; cin >> gas ;
            cout << "Full miles: " ; cin >> miles;
            cout << "MPG: " <<setprecision(3) << fixed << showpoint<<  miles/gas << endl ;
            cout << (9 < 10 ? 1: 0) << endl;
            int num = 5 ;
            cout << num++ << endl;
            cout << ++num << endl ;

       return 0; 
   }  



  